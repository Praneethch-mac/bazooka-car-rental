import React from "react";

function Home() {
  return (
    <div>
      <h1>Welcome to Zoomcar Clone</h1>
      <p>Select your location and rent a car easily.</p>
    </div>
  );
}

export default Home;