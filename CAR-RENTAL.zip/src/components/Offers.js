import React from "react";

function Offers() {
  return (
    <div>
      <h2>Current Offers</h2>
      <p>Use code ZOOM20 to get 20% off!</p>
    </div>
  );
}

export default Offers;