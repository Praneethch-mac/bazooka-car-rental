import React from "react";

const cars = [
  { id: 1, name: "Hyundai i20", price: "₹500/hr" },
  { id: 2, name: "Maruti Suzuki Swift", price: "₹450/hr" },
  { id: 3, name: "Tata Nexon", price: "₹600/hr" }
];

function Cars() {
  return (
    <div>
      <h2>Available Cars</h2>
      <ul>
        {cars.map(car => (
          <li key={car.id}>{car.name} - {car.price}</li>
        ))}
      </ul>
    </div>
  );
}

export default Cars;